DARK_THEME = '''
QWidget { background:#1e1e1e; color:#eaeaea; font-family:Consolas; }
QPushButton { background:#2b2b2b; border:1px solid #444; padding:6px; }
'''
