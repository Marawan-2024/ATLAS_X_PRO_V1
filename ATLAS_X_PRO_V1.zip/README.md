ATLAS-X Pro Antivirus (Release v1)
================================
Features:
- Professional PyQt5 GUI (Dark Mode)
- Charts Dashboard
- Real-Time File Watchdog
- Modular Engine (Signatures + Heuristics + AI placeholder)
- Windows-ready

Quick Start:
1) Install Python 3.10+
2) pip install -r requirements.txt
3) python main.py
