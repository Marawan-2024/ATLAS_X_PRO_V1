from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as Canvas
from matplotlib.figure import Figure

class Chart(Canvas):
    def __init__(self):
        fig = Figure(figsize=(4,3))
        self.ax = fig.add_subplot(111)
        super().__init__(fig)
        self.update_chart([0,1,2,3],[1,2,1,3])
    def update_chart(self, x, y):
        self.ax.clear()
        self.ax.plot(x,y)
        self.draw()
