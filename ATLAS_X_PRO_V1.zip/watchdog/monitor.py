from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class WatchHandler(FileSystemEventHandler):
    def __init__(self, callback):
        self.callback = callback
    def on_created(self, event):
        if not event.is_directory:
            self.callback(event.src_path)

class RealTimeMonitor:
    def __init__(self, path, callback):
        self.path = path
        self.handler = WatchHandler(callback)
        self.observer = Observer()
    def start(self):
        self.observer.schedule(self.handler, self.path, recursive=True)
        self.observer.start()
    def stop(self):
        self.observer.stop()
        self.observer.join()
