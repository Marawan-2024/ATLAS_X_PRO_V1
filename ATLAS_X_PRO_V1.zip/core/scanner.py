import os, sqlite3, hashlib
DB='database/signatures.db'

class FileScanner:
    def __init__(self):
        os.makedirs('database', exist_ok=True)
        self.conn = sqlite3.connect(DB)
        self.conn.execute('CREATE TABLE IF NOT EXISTS signatures (hash TEXT PRIMARY KEY)')
        self.conn.commit()

    def hash_file(self, path):
        h = hashlib.sha256()
        try:
            with open(path,'rb') as f:
                for c in iter(lambda: f.read(8192), b''):
                    h.update(c)
            return h.hexdigest()
        except Exception:
            return None

    def scan(self, path):
        h = self.hash_file(path)
        if not h: return 0.0
        cur = self.conn.execute('SELECT 1 FROM signatures WHERE hash=?',(h,))
        return 1.0 if cur.fetchone() else 0.0
