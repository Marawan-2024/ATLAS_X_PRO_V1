from core.scanner import FileScanner
from core.heuristics import HeuristicEngine
from ai.risk_score import RiskScorer

class AtlasEngine:
    def __init__(self):
        self.scanner = FileScanner()
        self.heuristics = HeuristicEngine()
        self.ai = RiskScorer()

    def analyze_file(self, path):
        s = self.scanner.scan(path)
        h = self.heuristics.analyze(path)
        a = self.ai.score(path)
        return round(s*0.4 + h*0.3 + a*0.3, 2)
