class RiskScorer:
    def score(self, path): return 0.2
