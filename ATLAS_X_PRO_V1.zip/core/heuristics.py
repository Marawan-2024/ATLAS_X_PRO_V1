class HeuristicEngine:
    def analyze(self, path): return 0.1
