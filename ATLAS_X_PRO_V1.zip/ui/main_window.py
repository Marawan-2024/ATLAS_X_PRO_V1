from PyQt5.QtWidgets import *
from ui.themes import DARK_THEME
from ui.charts import Chart
from core.engine import AtlasEngine

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.engine = AtlasEngine()
        self.setWindowTitle("ATLAS-X Pro Antivirus")
        self.resize(1000,650)
        self.setStyleSheet(DARK_THEME)

        central = QWidget(); self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        layout.addWidget(QLabel("ATLAS-X Pro Antivirus - Protection Active"))
        self.chart = Chart(); layout.addWidget(self.chart)

        btn = QPushButton("Scan File")
        btn.clicked.connect(self.scan_file)
        layout.addWidget(btn)

    def scan_file(self):
        path,_ = QFileDialog.getOpenFileName(self,"Select File")
        if path:
            score = self.engine.analyze_file(path)
            QMessageBox.information(self,"Scan Result",f"Risk Score: {score}")
